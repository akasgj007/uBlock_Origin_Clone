# Safari platform

The Safari platform does not support the WebExtensions
framework and thus is no longer supported. Consequently
the code base has been removed.

Note that the code base here was before the
[official fork Safari fork](https://github.com/el1t/uBlock-Safari) was
created, so it does not correspond to the version of
uBlock Origin which could be installed on Safari.

The last commit which contains the code is
917f3620e0c08b722bbd4d400bca2735d9f6975f.

You can browse the last state of the removed code base at
<https://github.com/gorhill/uBlock/tree/917f3620e0c08b722bbd4d400bca2735d9f6975f/platform/safari>.
